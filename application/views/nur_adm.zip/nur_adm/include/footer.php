<footer class="main-footer">
    <strong>Copyright &copy; <a href="http://micaeduco.com/" target='_blank'>MICA EDUCATIONAL COMPANY PVT. LTD.</a></strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 0.1
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
</body>
</html>
