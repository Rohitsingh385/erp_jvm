<center><a href='<?php echo base_url('adm_nur/Admin'); ?>' target='_blank' style='color:red; font-size:25px;'>Click Here to proceed to fill up Registration Form</a></center>

<iframe src="<?php echo base_url('assets/logo/jvm_ins_2022.pdf'); ?>" style='width:100%; height:100%;'>
	
</iframe>


<center><a href='<?php echo base_url('adm_nur/Admin'); ?>' target='_blank' style='color:red; font-size:25px;'>Click Here to proceed to fill up Registration Form</a></center>